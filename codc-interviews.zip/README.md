# DevOps Assignment

## Introduction

The assignment for the interview consists of two exercises:

1. A high-level architecture design
2. An Azure DevOps pipeline.

**Once done, reply to the email from which you downloaded this assignment and reply to it with a link to a repository containing your solutions.**

## Exercise 1: High-Level Architecture Design

The **high_level_design.pdf** contains a diagram of a high level architecture. The assignment for you is to:

1. Create a design using Azure Services with this architecture in mind.
2. Then explain briefly in a Markdown file what each service does and why you chose it.
3. If diagrams help your explanation create some with draw.io, mermaid, or the like and include them in your Markdown.

## Exercise 2: Azure Devops Pipeline

The **pipeline_exercise** directory contains a static website.

1. Open the **HTML** file and you will see some remarks regarding some issues that a pipeline is having.
2. Fix the pipeline.
